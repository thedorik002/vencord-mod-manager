# Changelog

## 1.5

- Added a saved English/Russian interface switcher; English is the default for new installs.
- Published manager source and visible bundled VoiceStreaks source.
- VoiceStreaks no longer has pair-specific hard-coded streak seeding.
- Added real `src/userplugins` folder scanning and physical selected-folder deletion.
- Preserved manually added userplugins through manager rebuilds.
- Fixed valid ASAR wrapper creation, Git-free Vencord archive builds, and Discord process waiting before replacement.
